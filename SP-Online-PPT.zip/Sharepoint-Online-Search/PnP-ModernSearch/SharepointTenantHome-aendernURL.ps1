﻿#Root-Site im Tenant ändern bzw. auf eine andere Seite zeigen lassen
#Neue Site muss "Communicationsite" sein!
#Source = Com-Site die neue Startseite werden soll
#Target = TenantURL für Sharepoint
#Archiv = wo alte Startseite abgelegt werden soll

Connect-SPOService -Url https://m365x396008-admin.sharepoint.com
Invoke-SPOSiteSwap -SourceUrl https://m365x396008.sharepoint.com/sites/com -TargetUrl https://m365x396008.sharepoint.com -ArchiveUrl https://m365x396008.sharepoint.com/sites/oldIntranet
