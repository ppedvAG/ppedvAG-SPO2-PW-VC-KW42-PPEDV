﻿Install-Module -Name SharePointPnPPowerShellOnline

#Install-Package SharePointPnPModernizationOnline -Version 1.0.2012

#https://docs.microsoft.com/de-de/sharepoint/dev/transform/modernize-userinterface-site-pages-powershell