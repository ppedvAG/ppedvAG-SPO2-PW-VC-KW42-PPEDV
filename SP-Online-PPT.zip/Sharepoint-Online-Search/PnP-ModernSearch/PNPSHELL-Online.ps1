﻿Install-Module SharepointPnPPowershellOnline -Force

connect-PnPOnline https://m365x79306701.sharepoint.com/sites/AlexS-modern -UseWebLogin
connect-PnPOnline https://m365x396008.sharepoint.com/sites/alex-Modern -UseWebLogin

get-PnPSite

get-PnPList

get-PnPClientSidePage -identity "suche(1)"  ###Modern-Search ist die Modern-Search.aspx Ausgabeseite(Resultpage)

set-PnPClientSidePage -identity "suche(1)" -LayoutType HeaderlessSearchResults
Disconnect-PnPOnline

##sharepoint customize a default site design###



###Bei Fehler: Get-PnPClientSidePage : Object reference not set to an instance of an object.
Get-Module -Name *pnppowershell* -ListAvailable | select Version

Uninstall-Module SharePointPnPPowerShellOnline -RequiredVersion 3.1.1809.0

Uninstall-Module -Name SharePointPnPPowerShellOnline -AllVersions -Force
Install-Module -Name PnP.PowerShell