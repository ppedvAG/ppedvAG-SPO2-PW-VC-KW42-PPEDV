﻿#Verbindung mit Mandanten

Connect-SPOService -Url https://m365xxxxx-admin.sharepoint.com -Credential admin@contoso.com