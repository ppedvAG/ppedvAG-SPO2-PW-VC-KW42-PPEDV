﻿Get-Module -Name Microsoft.Online.SharePoint.PowerShell -ListAvailable | Select Name,Version

Install-Module -Name Microsoft.Online.SharePoint.PowerShell

##LoginName und o365-orgName eintragen!

$adminUPN="LoginName"
$orgName="M365xxxxx"
$userCredential = Get-Credential -UserName $adminUPN -Message "Type the password."
Connect-SPOService -Url https://$orgName-admin.sharepoint.com -Credential $userCredential

###Nur bei MFA

$orgName="<name of your Office 365 organization, example: contosotoycompany>"
Connect-SPOService -Url https://$orgName-admin.sharepoint.com

Connect-SPOService -Url https://M365xxxxx-admin.sharepoint.com





New-SPOSite -Url https://m365xxxxx.sharepoint.com/sites/Alexander-Communication -Owner admin@M365xxxxx.onmicrosoft.com -Template SITEPAGEPUBLISHING#0 -LocaleId 1031 -StorageQuota 10

Set-SPOSite -Identity https://m365xxxxxx.sharepoint.com/sites/Alexander-Communication -Title MeinIntranet

Invoke-SPOSiteSwap -SourceUrl https://m365xxxxxx.sharepoint.com/sites/Alexander-Communication -TargetUrl https://M365xxxxxx.sharepoint.com -ArchiveUrl https://M365xxxxxx.sharepoint.com/sites/oldPortalXY
