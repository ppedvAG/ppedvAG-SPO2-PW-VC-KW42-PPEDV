﻿Connect-SPOService -Url https://xxxxxxx-admin.sharepoint.com 
Set-SPOsite -Identity https://xxxxxxx.sharepoint.com/sites/Intranet -DenyAddAndCustomizePages 0